/* Add your Supabase Project URL and anon/public key here.
   Never put a service_role key in this file. */
window.MATIC_SITE_CONFIG = {
  supabaseUrl: 'PASTE_SUPABASE_PROJECT_URL_HERE',
  supabaseAnonKey: 'PASTE_SUPABASE_ANON_PUBLIC_KEY_HERE'
};
